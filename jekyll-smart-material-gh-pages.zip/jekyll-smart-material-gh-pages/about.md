---
layout: page
title: About
permalink: /about/
---

This is Smart Material theme.

Github repository: [https://github.com/ssokurenko/jekyll-smart-material](https://github.com/ssokurenko/jekyll-smart-material)

